﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace QuanLySach
{
    class LopChung
    {
        string ketnoi = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\TRAN ANH\\source\\repos\\QuanLySach\\QuanLySach\\QuanLySach.mdf;Integrated Security=True";
        SqlConnection conn;
        public LopChung()
        {
            conn = new SqlConnection(ketnoi);
        }
        public int ThemSuaXoa(string sql)
        {
            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            int kt = comm.ExecuteNonQuery();
            comm.Clone();
            return kt;

        }
        public DataTable LoadDL(string sql)
        {
            SqlDataAdapter data = new SqlDataAdapter(sql, conn);

            DataTable dta = new DataTable();
            data.Fill(dta);
            return dta;
        }
        public object LayGt(string sql)
        {
            SqlCommand comm = new SqlCommand(sql, conn);
            conn.Open();
            object kt = comm.ExecuteScalar();
            conn.Close();
            return kt;
        }

        internal object LoadDL(object slq)
        {
            throw new NotImplementedException();
        }
    }
}
