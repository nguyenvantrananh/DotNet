﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySach
{
    public partial class frm_QuanLySach : Form
    {
        LopChung lc = new LopChung();
        public frm_QuanLySach()
        {
            InitializeComponent();
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_ThueSach"] != null)
            {
                this.Close();

            }
        }

        private void trangThuêSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_ThueSach"] == null)
            {
                frm_ThueSach ts = new frm_ThueSach();
                ts.MdiParent = this;
                ts.Show();
            }
            else Application.OpenForms["frm_ThueSach"].Activate();
        }

        private void dt_List_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        

        private void frm_QuanLySach_Load(object sender, EventArgs e)
        {
            
        }

        private void trangXemSáchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_XemSach"] == null)
            {
                frm_XemSach ts = new frm_XemSach();
                ts.MdiParent = this;
                ts.Show();
            }
            else Application.OpenForms["frm_XemSach"].Activate();
        }
    }
}
