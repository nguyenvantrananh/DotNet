﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySach
{
    public partial class frm_DangNhap : Form
    {
        LopChung lc = new LopChung();
        public frm_DangNhap()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frm_DangNhap_Load(object sender, EventArgs e)
        {

        }

        private void btn_Dangnhap_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "Select COUNT (*) from ACOUNT where USERS = '" + txt_DangNhap.Text + "' and PASSWORDS = '" + txt_MatKhau.Text + "'";
                int kq = (int)lc.LayGt(sql);
                if (kq >= 1)
                {
                    MessageBox.Show("Đăng nhập thành công");
                    frm_QuanLySach f = new frm_QuanLySach();
                    this.Hide();
                    f.ShowDialog();
                    this.Show();
                }
                else MessageBox.Show("Sai tên hoặc mật khẩu, đăng nhập thất bại");
            }
            catch (Exception )
            {

                MessageBox.Show("Sai tên hoặc mật khẩu, đăng nhập thất bại");
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chb_Hienthi_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_Hienthi.Checked == true)
                txt_MatKhau.UseSystemPasswordChar = false;
            else txt_MatKhau.UseSystemPasswordChar = true;
        }
    }
}
