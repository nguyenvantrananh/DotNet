﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySach
{
    public partial class frm_XemSach : Form
    {
        LopChung lc = new LopChung();
        public frm_XemSach()
        {
            InitializeComponent();
        }

        private void dt_List_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public void LoadData()
        {
            string sql = "Select * from SACH";
            dt_List.DataSource = lc.LoadDL(sql);
        }

        private void frm_XemSach_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btn_Tim_Click(object sender, EventArgs e)
        {
            string find = "select * from SACH where TENSACH = N'" + txt_Tim.Text + "'";
            dt_List.DataSource = lc.LoadDL(find);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
