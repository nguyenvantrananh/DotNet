﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySach
{
    public partial class frm_ThueSach : Form
    {
        LopChung lc = new LopChung();
        public frm_ThueSach()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public void LoadData()
        {
            string sql = "Select * from MUONSACH";
            dt_Muonsach.DataSource = lc.LoadDL(sql);
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = " insert into MUONSACH(HOTEN,NGAYSINH,DIACHI,SDT,MASS) values (N'" + txt_Hoten.Text + "',Convert(datetime,'" + dt_Ngaysinh.Text + "',103),N'" + txt_Diachi.Text + "',N'" + txt_Sdt.Text + "','" + cbb_Tensach.SelectedValue + "')";
                int kq = lc.ThemSuaXoa(sql);
                if (kq >= 1) MessageBox.Show("thành công !");
                else MessageBox.Show(" thất bại !");
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm_ThueSach_Load(object sender, EventArgs e)
        {
            LoadData();
            string sql = "Select TENSACH,MASS from SACH";
            cbb_Tensach.DataSource = lc.LoadDL(sql);
            cbb_Tensach.DisplayMember = "TENSACH";
            cbb_Tensach.ValueMember = "MASS";
        }

        private void dt_Ngaysinh_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
